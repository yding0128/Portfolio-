--Retrieve the names of the employees who work in a department 
--with a budget exceeding 1,000,000.
--Print the output in sorted order of name.
SELECT DISTINCT Emp.ename
FROM ((Emp
INNER JOIN Works ON Emp.eid = Works.eid)
INNER JOIN Dept ON Works.did = Dept.did)
WHERE Dept.budget > 1000000
ORDER BY Emp.ename;
