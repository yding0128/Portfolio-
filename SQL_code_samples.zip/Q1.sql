SELECT  Emp.ename, Emp.age
FROM ((Emp
INNER JOIN Works ON Emp.eid = Works.eid)
INNER JOIN Dept ON Works.did = Dept.did)
WHERE Dept.dname = 'Legal'
ORDER BY (Emp.ename, Emp.age);