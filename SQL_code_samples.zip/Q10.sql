--Retrieve the names of managers who manage the departments with the largest budget.
--Print the output in sorted order of name.
SELECT Emp.ename
FROM ((Emp
INNER JOIN Works ON Emp.eid = Works.eid)
INNER JOIN Dept ON Works.did = Dept.did)
WHERE Emp.eid = Dept.managerid 
AND Dept.budget = (SELECT MAX(Dept.budget)
                    FROM Dept)
ORDER BY Emp.ename;