--If a manager manages more than one department, they control the sum of all the budgets
-- for those departments. Retrieve the managerids of managers who control more than 5 million.
-- Print the output in order of managerid.
SELECT Dept.managerid
FROM Dept
GROUP BY Dept.managerid
HAVING SUM(Dept.budget) > 5000000
ORDER BY Dept.managerid;

