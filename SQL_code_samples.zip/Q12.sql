--Retrieve the names of managers who manage only departments with budgets larger than 1 million,
--but at least one department with a budget less than 5 million.
--Print the output in sorted order of name.
SELECT Emp.ename
FROM Emp, Dept
WHERE Emp.eid = Dept.managerid
AND Dept.budget > 1000000
AND EXISTS ( 
 SELECT managerid
 FROM Dept 
 WHERE Emp.eid = Dept.managerid
 and Dept.budget < 5000000
) 
GROUP BY Emp.ename;


-- where managerid = emp.eid
-- and exists ( 
--  select *
--  from works
--  join dept on works.did = dept.did
--  where works.eid = works.eid
--  and dept.budget >= 1e6
-- )
-- and not exists (
--  select *
--  from works join dept on works.did = dept.did
--  where works.eid = works.eid
--  and dept.budget < 1e6
-- )
-- and exists ( 
--  select *
--  from works join dept on works.did = dept.did
--  where works.eid = works.eid 
--  and dept.budget < 5e6
-- ) 

--order by ename;
